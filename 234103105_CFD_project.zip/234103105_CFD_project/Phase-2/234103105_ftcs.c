#include <stdio.h>
#include <stdlib.h>
#include<math.h>
int main()
{
    int M=101;
    int Ren=100;
    double dy;
    dy=1.0/(M-1);
    double dt = 0.005;
    double gamma = dt/(Ren*dy*dy);
    double u[M];
    double u_old[M];
    int k=0;
    int j;
    for( j=0;j<M-1;j++)
    {
        u[j]=0.0;
    }
    u[M-1]=1.0;
    FILE *f1=fopen("error_A2_FTCS.txt", "w");
    double error=1.0;
    do
    {
        error=0.0;
        for( j=0;j<M;j++)
            {
                u_old[j]=u[j];    // storing previous iteration values inside another array
            }
        for( j=1;j<M-1;j++)
        {
            u[j]=u[j] + gamma*(u[j+1]+u[j-1]-2*u[j]);  // ftcs discretized equation
            error= error+pow((u[j]-u_old[j]),2.0);
        }
     error=sqrt(error/(M-2));
     printf("Iteration %d\t", k);
     printf("Error %.10lf\n", error);
     fprintf(f1,"%d\t%.10lf\n",k ,error);
     k=k+1;
    }while(error>1e-6);
    fclose(f1);
    FILE *c1=fopen("vel_profile_a2_FTCS.plt", "w");
    fprintf(c1,"VARIABLES = \"Y\", \"U\"\n");
    fprintf(c1, "ZONE T = \"BLOCK1\", J = %d, F = POINT\n\n",M);
    for(j=0;j<M;j++)
        {
            fprintf(c1, " %lf \t %lf \n", j*dy, u[j]);

        }
    fclose(c1);
    return 0;
}

