#include <stdio.h>
#include <stdlib.h>
#include<math.h>
int main()
{
    int N,M;
    printf("Enter the value of M");
    scanf("%d",&M);
    printf("Enter the value of N");
    scanf("%d",&N);
    double strf[M][N],u[M][N],v[M][N],w[M][N],w_old,strf_old,error_s,error_w,error_wmax,error_smax,delx,dely,beta;
    int i,j,Rey;
    printf("Enter the value of Reynolds no.");
    scanf("%d",&Rey);
    delx=1.0/M;
    dely=1.0/N;
    beta=delx/dely;
    for(i=1;i<M-1;i++)
    {   for( j=1;j<N-1;j++)
        {
            strf[i][j]=0.0;  // Initialize interior points equal to zero
            u[i][j]=0.0;
            v[i][j]=0.0;
            w[i][j]=0.0;
        }
    }
    for( j=0;j<N;j++)
    {
        u[0][j]=0.0;     //left boundary
        v[0][j]=0.0;
        w[0][j]=(2/pow(delx,2.0))*(strf[0][j]-strf[1][j]);
        strf[0][j]=0.0;


        u[M-1][j]=0.0;     //right boundary
        v[M-1][j]=0.0;
        w[M-1][j]=(2/pow(delx,2.0))*(strf[M-1][j]-strf[M-2][j]);
        strf[M-1][j]=0.0;
    }
    for(i=0;i<M;i++)
    {
        u[i][0]=0.0;     //bottom boundary
        v[i][0]=0.0;
        w[i][0]=(2/pow(dely,2.0))*(strf[i][0]-strf[i][1]);
        strf[i][0]=0.0;

        u[i][N-1]=1.0;     //top boundary
        v[i][N-1]=0.0;
        w[i][N-1]=(2/pow(dely,2.0))*(strf[i][N-1]-strf[i][N-2]-dely);
        strf[i][N-1]=0.0;
    }
    FILE *f1=fopen("stream.plt","w");
    FILE *f2=fopen("vel.plt","w");
    FILE *f3=fopen("u_profile.plt", "w");
    FILE *f4=fopen("v_profile.plt", "w");
    fprintf(f1,"VARIABLES =\"X\", \"Y\", \"PSI\"\n");
    fprintf(f1, "ZONE T = \"BLOCK1\", I = %d, J = %d, F = POINT\n\n",M,N);
    fprintf(f2,"VARIABLES =\"X\", \"Y\", \"U\", \"V\"\n");
    fprintf(f2, "ZONE T = \"BLOCK1\", I = %d, J = %d, F = POINT\n\n",M,N);
    fprintf(f3,"VARIABLES = \"Y\", \"U\"\n");
    fprintf(f3, "ZONE T = \"BLOCK1\", I = %d, F = POINT\n\n",N);
    fprintf(f4,"VARIABLES = \"X\", \"V\"\n");
    fprintf(f4, "ZONE T = \"BLOCK1\", I = %d, F = POINT\n\n",M);
    do
    {
        error_s=error_w=error_wmax=error_smax=0;
        for(j=1;j<N-1;j++)       //  computing updated values of w & stream function from discretized equation
        {
            for(i=1;i<M-1;i++)
            {
                w_old=w[i][j];
                strf_old=strf[i][j];
                w[i][j]=( (1 - (strf[i][j+1]-strf[i][j-1])*(beta*Rey/4) )*w[i+1][j] + (1 + (strf[i][j+1]-strf[i][j-1])*(beta*Rey/4) )*w[i-1][j] + (1 + (strf[i+1][j]-strf[i-1][j])*(Rey/(4*beta)) )*pow(beta,2.0)*w[i][j+1] + (1 - (strf[i+1][j]-strf[i-1][j])*(Rey/(4*beta)) )*pow(beta,2.0)*w[i][j-1])/(2*(1+pow(beta,2.0)));
                strf[i][j]= (w[i][j]*pow(delx,2.0) + pow(beta,2.0)*(strf[i][j+1]+strf[i][j-1]) + strf[i+1][j]+strf[i-1][j])/(2*(1+pow(beta,2.0)));
                error_s = pow(strf_old-strf[i][j],2.0);
                if(error_s>error_smax)
                {
                    error_smax=error_s;
                }
                error_w = pow(w_old-w[i][j],2.0);
                if(error_w>error_wmax)
                {
                    error_wmax=error_w;
                }
            }
        }
        error_wmax=sqrt(error_wmax);
        error_smax=sqrt(error_smax);
        for(i=0;i<M;i++)
        {
            w[i][0]=(2/pow(dely,2.0))*(strf[i][0]-strf[i][1]);
            w[i][N-1]=(2/pow(dely,2.0))*(strf[i][N-1]-strf[i][N-2]-dely);
        }
        for( j=0;j<N;j++)
        {
            w[0][j]=(2/pow(delx,2.0))*(strf[0][j]-strf[1][j]);
            w[M-1][j]=(2/pow(delx,2.0))*(strf[M-1][j]-strf[M-2][j]);
        }
        printf("%.8lf \t %.8lf \n",error_wmax,error_smax);
    }while(error_smax>1e-6 || error_wmax>1e-6);
    for(j=1;j<N-1;j++)
        {
            for(i=1;i<M-1;i++)
            {
                u[i][j] = (strf[i][j+1]-strf[i][j-1])/(2*dely);
                v[i][j] = -1*(strf[i+1][j]-strf[i-1][j])/(2*delx);
            }
        }
    for(j=0;j<N;j++)
        {
            for(i=0;i<M;i++)
            {
                fprintf(f1, "%lf \t %lf \t %lf \n", i*delx, j*dely, strf[i][j]);
                fprintf(f2, "%lf \t %lf \t %lf \t %lf \n", i*delx, j*dely, u[i][j], v[i][j]);
                if(i==(M/2)-1)
                {
                    fprintf(f3, " %lf \t %lf \n", j*dely, u[i][j]);
                }
                if(j==(N/2)-1)
                {
                    fprintf(f4, " %lf \t %lf \n", i*delx, v[i][j]);
                }
            }
        }
    fclose(f1);
    fclose(f2);
    fclose(f3);
    fclose(f4);
    return 0;
}
