#include <stdio.h>
#include <stdlib.h>
#include<math.h>
int main()
{
    int M=101;
    int Ren=100;
    double dy;
    dy=1.0/(M-1);
    double dt = 0.01;
    double gamma = dt/(Ren*dy*dy);
    double u[M];
    double prev_val;
    int k=0;
    int j;
    for( j=0;j<M-1;j++)
    {
        u[j]=0.0;
    }
    u[M-1]=1.0;
    FILE *f1=fopen("error_A2_BTCS_Gauss.txt", "w");
    double error=1.0;
    double a1[M],a2[M],a3[M],b[M],A[M][M];
    a1[0]=a3[0]=b[0]=a1[M-1]=a3[M-1]=0;
    a2[M-1]=a2[0]=b[M-1]=1.0;
    double sum;
    do
    {
        error=0.0;
        for( j=1;j<M-1;j++)
        {
            a2[j]=-1*(1+2*gamma); // coefficient of u(j) in discretized equation
            a1[j]=a3[j]=gamma; // coefficients of u(j-1) & u(j+1) in discretized equation
            b[j]=-1*u[j];      // RHS of discretized equation
        }
        b[1]=b[1]-a1[1]*u[0];  // at lower boundary u is fixed and can be taken to RHS in discretized equation
        a1[1]=0;
        b[M-2]=b[M-2]-a3[M-2]*u[M-1]; // at upper boundary u is fixed and can be taken to RHS in discretized equation
        a3[M-2]=0;
        for( j=0;j<M;j++)
        {   for( int i=0;i<M;i++)
            {
                A[i][j]=0.0;
            }
        }
        for( j=1;j<M-1;j++)       // assembling the coefficient matrix using a1,a2,a3
        {
            A[j][j]=a2[j];
            A[j][j-1]=a1[j];
            A[j-1][j]=a3[j-1];
        }
        A[0][0]=A[M-1][M-1]=1.0;
        for( j=0;j<M;j++)
        {   sum=0.0;
            for( int i=0;i<M;i++)
            {
                sum=sum+(A[i][j]*u[i]);     // calculating summation of aij * uj
            }
            prev_val=u[j];
            u[j]=u[j]+(b[j]-sum)/A[j][j];   // uj recursive addition with residue/ajj
            error= error+pow((u[j]-prev_val),2.0);
        }
     error=sqrt(error/(M));
     printf("Iteration %d\t", k);
     printf("Error %.10lf\n", error);
     fprintf(f1,"%d\t%.10lf\n",k ,error);
     k=k+1;
    }while(error>1e-6);
    fclose(f1);
    FILE *c1=fopen("vel_profile_a2_BTCS_Gauss.plt", "w");
    fprintf(c1,"VARIABLES = \"Y\", \"U\"\n");
    fprintf(c1, "ZONE T = \"BLOCK1\", J = %d, F = POINT\n\n",M);
    for(j=0;j<M;j++)
        {
            fprintf(c1, " %lf \t %lf \n", j*dy, u[j]);
        }
    fclose(c1);
    return 0;
}

