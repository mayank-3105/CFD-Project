#include <stdio.h>
#include <stdlib.h>
#include<math.h>
int main()
{
    int M=101;
    int Ren=100;
    double dy;
    dy=1.0/(M-1);
    double dt = 0.01;
    double gamma = dt/(Ren*dy*dy);
    double u[M];
    double prev_val;
    int k=0;
    int j;
    for( j=0;j<M-1;j++)
    {
        u[j]=0.0;
    }
    u[M-1]=1.0;
    FILE *f1=fopen("error_A2_crank.txt", "w");
    double error=1.0;
    double a[M-1],b[M-1],c[M-1],d[M-1],P[M-1],Q[M-1];
    a[0]=b[0]=c[0]=d[0]=P[0]=Q[0]=0;
    do
    {
        error=0.0;
        for(j=1;j<M-1;j++)  // TDMA algorithm
        {
             a[j]=-1*(1+gamma);  // allocating coefficients from discretized equation
             b[j]=gamma/2;
             c[j]=gamma/2;
             d[j]=(gamma-1)*u[j]-(gamma/2)*(u[j-1]+u[j+1]);
             c[1]=0;
             d[1]=(gamma-1)*u[1]-(gamma/2)*(u[0]+u[2]+u[0]);
             b[M-2]=0;
             d[M-2]=(gamma-1)*u[M-2]-(gamma/2)*(u[M-1]+u[M-3]+u[M-1]);
             P[j]=-1*b[j]/(a[j]+c[j]*P[j-1]);  // computing p & q
             Q[j]=(d[j]-c[j]*Q[j-1])/(a[j]+c[j]*P[j-1]);
        }
        u[M-2]=Q[M-2];
        for(j=M-3;j>0;j--)  // reverse substitution to compute uj
        {
            prev_val=u[j];
            u[j]=P[j]*u[j+1]+Q[j];
            error= error+pow((u[j]-prev_val),2.0);
        }
     error=sqrt(error/(M-2));
     printf("Iteration %d\t", k);
     printf("Error %.10lf\n", error);
     fprintf(f1,"%d\t%.10lf\n",k ,error);
     k=k+1;
    }while(error>1e-6);
    fclose(f1);
    FILE *c1=fopen("vel_profile_a2_crank.plt", "w");
    fprintf(c1,"VARIABLES = \"Y\", \"U\"\n");
    fprintf(c1, "ZONE T = \"BLOCK1\", J = %d, F = POINT\n\n",M);
    for(j=0;j<M;j++)
        {
            fprintf(c1, " %lf \t %lf \n", j*dy, u[j]);
        }
    fclose(c1);
    return 0;
}

