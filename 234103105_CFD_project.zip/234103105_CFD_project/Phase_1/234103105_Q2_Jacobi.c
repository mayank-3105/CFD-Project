#include <stdio.h>
#include <stdlib.h>
#include<math.h>
int main()
{
    int N,M;
    double dx,dy;
    printf("Enter the value of M");
    scanf("%d",&M);
    printf("Enter the value of N");
    scanf("%d",&N);
    printf("Enter the value of dx");
    scanf("%lf",&dx);
    printf("Enter the value of dy");
    scanf("%lf",&dy);
    double beta = dx/dy;
    double T[M][N];
    double T_old[M][N];
    int k=0;
    int i,j;
    for(i=1;i<M-1;i++)
    {   for( j=1;j<N-1;j++)
        {
            T[i][j]=0.0;  // Initialize interior points equal to zero
        }
    }
    for( j=0;j<N;j++)
    {
        T[0][j]=1.0;  // Left boundary condition
        T[M-1][j]=1.0;  // Right boundary condition
    }
    for(i=0;i<M;i++)
    {
         T[i][0]=1.0;  // Bottom boundary condition
         T[i][N-1]=0.0;  // Top boundary condition
    }
    FILE *f1=fopen("error_q2_jacobi.txt", "w");
    double error=1.0; // Initialize error
    do
    {
        for(i=0;i<M;i++)
        {
            for( j=0;j<N;j++)
            {
                T_old[i][j]=T[i][j];
            }
        }
        for(i=1;i<M-1;i++)
        {
            for( j=1;j<N-1;j++)
            {
                T[i][j]=((pow(beta,2.0))*(T_old[i][j-1]+T_old[i][j+1])+T_old[i-1][j]+T_old[i+1][j])/(2*(1+(pow(beta,2.0))));
            }
        }
        error=0.0;
        for(i=1;i<M-1;i++)
        {
            for( j=1;j<N-1;j++)
            {
                error= error+pow((T[i][j]-T_old[i][j]),2.0);
            }
        }
        error=sqrt(error/((M-2)*(N-2)));  //Compute RMS value of error
        printf("Iteration %d\t", k);
        printf("Error %.10lf\n", error);
        fprintf(f1,"%d\t%.10lf\n",k ,error);
        k=k+1;
    }while(error>1e-6);
    fclose(f1);
    FILE *c1=fopen("contours_Q2_Jacobi.plt", "w");
    fprintf(c1,"VARIABLES =\"X\", \"Y\", \"T\"\n");
    fprintf(c1, "ZONE T = \"BLOCK1\", I = %d, J = %d, F = POINT\n\n",M,N);
    for(i=0;i<M;i++)
        {
            for( j=0;j<N;j++)
            {
                fprintf(c1, "%lf \t %lf \t %lf \n", i*dx, j*dy, T[i][j]);
            }
        }
    fclose(c1);
    return 0;
}
