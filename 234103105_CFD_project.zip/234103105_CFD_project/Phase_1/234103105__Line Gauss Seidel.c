#include <stdio.h>
#include <stdlib.h>
#include<math.h>
int main()
{
    int N,M;
    double dx,dy;
    printf("Enter the value of M");
    scanf("%d",&M);
    printf("Enter the value of N");
    scanf("%d",&N);
    printf("Enter the value of dx");
    scanf("%lf",&dx);
    printf("Enter the value of dy");
    scanf("%lf",&dy);
    double beta = dx/dy;
    double T[M][N];
    int k=0;
    int i,j;
    for(i=1;i<M-1;i++)
    {   for( j=1;j<N-1;j++)
        {
            T[i][j]=0.0;  // Initialize interior points equal to zero
        }
    }
    for( j=0;j<N;j++)
    {
        T[0][j]=1.0;  // Left boundary condition
        T[M-1][j]=1.0;  // Right boundary condition
    }
    for(i=0;i<M;i++)
    {
         T[i][0]=1.0;  // Bottom boundary condition
         T[i][N-1]=0.0;  // Top boundary condition
    }
    FILE *f1=fopen("error_Q2_LGSI.txt", "w");
    double error=1.0; // Initialize error
    double prev_val;
    double a[M-1],b[M-1],c[M-1],d[M-1],P[M-1],Q[M-1];  // Initialize array to calculate ai,bi,ci,di,Pi & Qi
    a[0]=b[0]=c[0]=d[0]=P[0]=Q[0]=0;
    do
    {
        error=0.0;
        for(j=1;j<N-1;j++)
        {
            for(i=1;i<M-1;i++)
            {
                a[i]=-2*(1+pow(beta,2.0));  // TDMA algorithm
                b[i]=1;
                c[i]=1;
                d[i]=-1*pow(beta,2.0)*(T[i][j-1]+T[i][j+1]);
                c[1]=0;
                d[1]=-1*(T[0][j]+pow(beta,2.0)*(T[1][j-1]+T[1][j+1]));
                b[M-2]=0;
                d[M-2]=-1*(T[M-1][j]+pow(beta,2.0)*(T[M-2][j-1]+T[M-2][j+1]));
                P[i]=-1*b[i]/(a[i]+c[i]*P[i-1]);
                Q[i]=(d[i]-c[i]*Q[i-1])/(a[i]+c[i]*P[i-1]);
            }
            T[M-2][j]=Q[M-2];  //Reverse substitution
            for(i=M-3;i>0;i--)
            {
                prev_val=T[i][j];
                T[i][j]=P[i]*T[i+1][j]+Q[i];
                error= error+pow((T[i][j]-prev_val),2.0);
            }
        }
        error=sqrt(error/((M-2)*(N-2))); //Compute RMS value of error
        printf("Iteration %d\t", k);
        printf("Error %.10lf\n", error);
        fprintf(f1,"%d\t%.10lf\n",k ,error);
        k=k+1;
    }while(error>1e-6);
    fclose(f1);
    FILE *c1=fopen("contours_Q2_LGSI.plt", "w");
    fprintf(c1,"VARIABLES =\"X\", \"Y\", \"T\"\n");
    fprintf(c1, "ZONE T = \"BLOCK1\", I = %d, J = %d, F = POINT\n\n",M,N);
    for(i=0;i<M;i++)
        {
            for( j=0;j<N;j++)
            {
                fprintf(c1, "%lf \t %lf \t %lf \n", i*dx, j*dy, T[i][j]);
            }
        }
    fclose(c1);
    return 0;
}

