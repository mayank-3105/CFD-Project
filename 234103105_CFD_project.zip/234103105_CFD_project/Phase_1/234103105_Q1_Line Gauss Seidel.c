#include <stdio.h>
#include <stdlib.h>
#include<math.h>
int main()
{
    int N,M;
    double dx,dy;
    printf("Enter the value of M");
    scanf("%d",&M);
    printf("Enter the value of N");
    scanf("%d",&N);
    printf("Enter the value of dx");
    scanf("%lf",&dx);
    printf("Enter the value of dy");
    scanf("%lf",&dy);
    double beta = dx/dy;
    double arr[M][N];
    int k=0;
    int i,j;
    for(i=1;i<M-1;i++)
    {   for( j=1;j<N-1;j++)
        {
            arr[i][j]=0.0;  // Initialize interior points equal to zero
        }
    }
    for( j=0;j<N;j++)
    {
        arr[0][j]=0.0;  // Left boundary condition
        arr[M-1][j]=arr[M-2][j];  // Right boundary condition
    }
    for(i=0;i<M;i++)
    {
        if(i<(M-1)/5)  // Bottom boundary condition
        {
         arr[i][0]=0.0;
        }
        else
        {
         arr[i][0]=100.0;
        }
         arr[i][N-1]=0.0;  // Top boundary condition
    }
    FILE *f1=fopen("error_Q1_LGSI.txt", "w");
    double error=1.0; // Initialize error
    double prev_val;
    double a[M-1],b[M-1],c[M-1],d[M-1],P[M-1],Q[M-1]; // Initialize array to calculate ai,bi,ci,di,Pi & Qi
    a[0]=b[0]=c[0]=d[0]=P[0]=Q[0]=0;
    do
    {
        error=0.0;
        for(j=1;j<N-1;j++)
        {
            for(i=1;i<M-1;i++)
            {
                a[i]=-2*(1+pow(beta,2.0));   //TDMA Algorithm
                b[i]=1;
                c[i]=1;
                d[i]=-1*pow(beta,2.0)*(arr[i][j-1]+arr[i][j+1]);
                c[1]=0;
                d[1]=-1*(arr[0][j]+pow(beta,2.0)*(arr[1][j-1]+arr[1][j+1]));
                b[M-2]=0;
                d[M-2]=-1*(arr[M-1][j]+pow(beta,2.0)*(arr[M-2][j-1]+arr[M-2][j+1]));
                P[i]=-1*b[i]/(a[i]+c[i]*P[i-1]);
                Q[i]=(d[i]-c[i]*Q[i-1])/(a[i]+c[i]*P[i-1]);
            }
            arr[M-2][j]=Q[M-2]; // Reverse substitution
            for(i=M-3;i>0;i--)
            {
                prev_val=arr[i][j];
                arr[i][j]=P[i]*arr[i+1][j]+Q[i];
                error= error+pow((arr[i][j]-prev_val),2.0);
            }
        }
        for(j=0;j<N;j++)
            {
                arr[M-1][j]=arr[M-2][j];  // Outlet boundary condition
            }
        error=sqrt(error/((M-2)*(N-2)));  //Compute RMS value of error
        printf("Iteration %d\t", k);
        printf("Error %.10lf\n", error);
        fprintf(f1,"%d\t%.10lf\n",k ,error);
        k=k+1;
    }while(error>1e-6);
    fclose(f1);
    FILE *c1=fopen("contours_Q1_LGSI.plt", "w");
    fprintf(c1,"VARIABLES =\"X\", \"Y\", \"PSI\"\n");
    fprintf(c1, "ZONE T = \"BLOCK1\", I = %d, J = %d, F = POINT\n\n",M,N);
    for(i=0;i<M;i++)
        {
            for( j=0;j<N;j++)
            {
                fprintf(c1, "%lf \t %lf \t %lf \n", i*dx, j*dy, arr[i][j]);
            }
        }
    fclose(c1);
    return 0;
}

